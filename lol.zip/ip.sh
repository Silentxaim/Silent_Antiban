iptables -I OUTPUT -p tcp -m string --string "www.anonymous.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "www.anonymous.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "gcloud.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "gcloud.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "googlesource.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "googlesource.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "android.googlesource.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "android.googlesource.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "dl.listdl.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "dl.listdl.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "crashsight.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "crashsight.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "crashsight.qq.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "crashsight.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "www.wetest.net" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "www.wetest.net" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "qq.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "qq.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "tencent.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "tencent.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "anticheatexpert.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "anticheatexpert.com" --algo bm -j DROP
iptables -I INPUT -s 61.151.168.203 -j DROP
iptables -I OUTPUT -s 61.151.168.203 -j DROP
iptables -I INPUT -s 76.223.65.111 -j DROP
iptables -I OUTPUT -s 76.223.65.111 -j DROP
iptables -I INPUT -p tcp --dport 80 -j REJECT
iptables -I OUTPUT -p tcp --dport 80 -j REJECT
iptables -I INPUT -p tcp --dport 80 -j DROP
iptables -I OUTPUT -p tcp --dport 80 -j DROP
iptables -I INPUT -p tcp --dport 20002 -j REJECT
iptables -I OUTPUT -p tcp --dport 20002 -j REJECT
iptables -I INPUT -p tcp --dport 20002 -j DROP
iptables -I OUTPUT -p tcp --dport 20002 -j DROP
iptables -I INPUT -p tcp --dport 8700 -j REJECT
iptables -I OUTPUT -p tcp --dport 8700 -j REJECT
iptables -I INPUT -p tcp --dport 8700 -j DROP
iptables -I OUTPUT -p tcp --dport 8700 -j DROP
iptables -I INPUT -p tcp --dport 8011 -j DROP
iptables -I OUTPUT -p tcp --dport 8011 -j DROP
iptables -I INPUT -p tcp --dport 10191 -j DROP
iptables -I OUTPUT -p tcp --dport 10191 -j DROP
iptables -I INPUT -p tcp --dport 10013 -j DROP
iptables -I OUTPUT -p tcp --dport 10013 -j DROP
iptables -I INPUT -p tcp --dport 8088 -j DROP
iptables -I OUTPUT -p tcp --dport 8088 -j DROP
iptables -I INPUT -p tcp --dport 8013 -j DROP
iptables -I OUTPUT -p tcp --dport 8013 -j DROP
iptables -I INPUT -p tcp --dport 20371 -j DROP
iptables -I OUTPUT -p tcp --dport 20371 -j DROP
iptables -I INPUT -p tcp --dport 9030 -j DROP
iptables -I OUTPUT -p tcp --dport 9030 -j DROP
iptables -I INPUT -p tcp --dport 8089 -j DROP
iptables -I OUTPUT -p tcp --dport 8089 -j DROP
iptables -I INPUT -p tcp --dport 9031 -j DROP
iptables -I OUTPUT -p tcp --dport 9031 -j DROP
iptables -I INPUT -p tcp --dport 15692 -j DROP
iptables -I OUTPUT -p tcp --dport 15692 -j DROP
pm disable com.pubg.imobile/com.sirius.flutter.im.MeemoBGService  &>/dev/null;
pm disable com.pubg.imobile/com.tencent.midas.oversea.newnetwork.service.APNetDetectService  &>/dev/null;
pm disable com.pubg.imobile/com.sirius.meemo.foreground_service.ForegroundService &>/dev/null;