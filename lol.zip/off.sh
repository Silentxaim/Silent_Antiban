#ANTIBAN 

Libanogs='com.pubg.imobile' #YOUR PUBG VERSION
echo " Clearing magisk logs & . files in storage dir "

rm -rf /cache/magisk.log.bak &>/dev/null
rm -rf /cache/magisk.log &>/dev/null
rm -rf /data/media/0/.* &>/dev/null

echo " Removing prex , puex .dat files and cache "

rm -rf /storage/emulated/0/Android/data/$Libanogs/pre*.dat
rm -rf /storage/emulated/0/Android/data/$Libanogs/puex*.dat
rm -rf /storage/emulated/0/Android/data/$Libanogs/cache

echo " Killing apps "

am force-stop com.pubg.imobile
am force-stop com.pubg.krmobile
am force-stop com.rekoo.pubgm
am force-stop com.vng.pubgmobile
am force-stop com.pubg.imobile

echo " Restoring paks folder permission "

echo " Restoring lib "

#A11
pm install -r /data/app/*/$Libanogs*/base.apk
#A10
pm install -r /data/app/$Libanogs*/base.apk

echo " Done "

clear


#ANTIBAN