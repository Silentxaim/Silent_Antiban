chattr -i /data/data/com.pubg.imobile
chattr -i /data/data/com.pubg.imobile/*
chattr -i /data/data/com.pubg.imobile/*/*
chattr -i /data/data/com.pubg.imobile/*/*/*
chattr -i /data/data/com.pubg.imobile/*/*/*/*
chattr -i /data/data/com.pubg.imobile/*/*/*/*/*
chattr -i /data/data/com.pubg.imobile/*/*/*/*/*/*
chattr -i /data/data/com.pubg.imobile/*/*/*/*/*/*/*
rm -rf /data/data/com.pubg.imobile/{shared_prefs,app_webview_imsdk_inner_webview,no_backup,cache,code_cache,app_databases,files,app_*}
rm -rf /data/data/com.pubg.imobile/databases/{*journal,crashSight_db_}
touch /data/data/com.pubg.imobile/{shared_prefs,app_webview,cache,app_crashSight,app_crashrecord}
chmod 000 /data/data/com.pubg.imobile/{shared_prefs,app_webview,,cache,app_crashSight,app_crashrecord}
touch /data/data/com.pubg.imobile/databases/crashSight_db_
chmod 000 /data/data/com.pubg.imobile/databases/crashSight_db_
mkdir /data/data/com.pubg.imobile/files
touch /data/data/com.pubg.imobile/files/ano_tmp
chmod 000 /data/data/com.pubg.imobile/files/ano_tmp
chmod 550 /data/data/com.pubg.imobile/files
chmod 700 /data/data/com.pubg.imobile
rm -rf /data/data/com.pubg.imobile/lib/{libanogs.so,libCrashSight.so}
cp /data/data/com.silent.mute/files/{libanogs.so,libCrashSight.so,libCrashSightCore.so,libgcloud.so} /data/data/com.pubg.imobile/lib/
chmod 755 /data/data/com.pubg.imobile/lib/{libanogs.so,libCrashSight.so,libCrashSightCore.so,libgcloud.so}
sleep 1
iptables -I OUTPUT -p tcp -m string --string "anticheatexpert.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "anticheatexpert.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "crashsight.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "crashsight.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "crashsight.qq.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "crashsight.qq.com" --algo bm -j DROP
iptables -I OUTPUT -p tcp -m string --string "dl.listdl.com" --algo bm -j DROP
iptables -I INPUT -p tcp -m string --string "dl.listdl.com" --algo bm -j DROP
sleep 1
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Demos,Logs,MMKV,RoleInfo,RoleIdnfo,TableDatas,UpdateInfo,PufferEifs0,PufferEifs1,PufferTmpDir,ImageDownload,coverversion.ini,apollo_*,Screenshots,WeaponDIY,Avatar,StatEventReportedFlag,GameErrorNoRecords}
touch /data/media/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Logs,MMKV,RoleInfo,PufferEifs0,PufferEifs1}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/{cache,prex_8bfb7f0a.dat}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/{TGPA,ca-bundle.pem,login-identifier.txt,vmpcloudconfig.json,.fff,tbslog,cacheFile.txt,hawk_data}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/{Engine,Epic*}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_pufferpatch_*,puffer_temp,*_cures.ifs.cures,apollo_reslist.flistnewlist,*_cures.ifs,new.filelist,*_cures.ifs.res,apollo_reslist.flist,filelist.json,PufferFileListAddtional.json}
sleep 2
am start -n com.pubg.imobile/com.epicgames.ue4.SplashActivity