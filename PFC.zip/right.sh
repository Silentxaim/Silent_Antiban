rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.imobile/{app_*,cache,code_cache,no_backup,files,shared_prefs}
rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.imobile/databases/{*-journal,crashSight_db_,__hs_log_store,awss3transfertable.db}
touch /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.imobile/{files,app_crashrecord,app_crashSight,shared_prefs,app_webview}
touch /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.imobile/databases/{crashSight_db_,__hs_log_store,awss3transfertable.db}
chmod 000 /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.imobile/{files,app_crashrecord,app_crashSight,shared_prefs,app_webview}
chmod 000 /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.imobile/databases/{crashSight_db_,__hs_log_store,awss3transfertable.db,*}
chmod 777 /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.imobile/databases/iMSDK.db
#Data Directory
#Bgmi
rm -rf /storage/emulated/0/{ASD,puex_dfaa3cad.dat}
rm -rf /storage/emulated/0/.backups/com.pubg.imobile
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/{cache,prex_8bfb7f0a.dat}
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/cache
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/{TGPA,ca-bundle.pem,login-identifier.txt,vmpcloudconfig.json,.fff,tbslog,cacheFile.txt,hawk_data,ProgramBinaryCache}
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/{Engine,Epic*}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Demos,Logs,MMKV,RoleInfo,RoleIdnfo,TableDatas,UpdateInfo,PufferEifs0,PufferEifs1,PufferTmpDir,ImageDownload,Coverversion.ini,apollo_*,Screenshots,WeaponDIY,StatEventReportedFlag,Avatar,GameErrorNoRecords,MoviesPakDir,Avatar,Voices}
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Demos,Logs,MMKV,PufferEifs0,PufferEifs1}
#Root
rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.imobile/{app_appcache,app_bugly,app_geolocation,app_textures,cache,code_cache,no_backup,app_cache,app_tmpcache}
rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.imobile/databases/*-journal
#Phone
rm -rf /storage/emulated/0/{ASD,puex_dfaa3cad.dat}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/prex_8bfb7f0a.dat
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/{TGPA,ca-bundle.pem,login-identifier.txt,vmpcloudconfig.json,.fff,tbslog,cacheFile.txt,hawk_data}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/{Engine,Epic*}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Demos,Logs,MMKV,RoleInfo,RoleIdnfo,TableDatas,UpdateInfo,PufferEifs0,PufferEifs1,PufferTmpDir,ImageDownload,Coverversion.ini,apollo_*,Screenshots,WeaponDIY,StatEventReportedFlag,Avatar,GameErrorNoRecords,MoviesPakDir,Avatar,Voices}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_pufferpatch_*,puffer_temp,*_cures.ifs.cures,apollo_reslist.flistnewlist,*_cures.ifs,new.filelist,*_cures.ifs.res,apollo_reslist.flist,filelist.json,PufferFileListAddtional.json,PufferFileList.json}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.imobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/{Activity,Arena,Commercial,Chat,Friend,PersonSpace,Rp,Store,Task,Download,GEM,https*,Loading,Lobby,LobbyBubble,Login,Match,Notice,Pet,PufferDownload,RoleInfo,Season,Setting,SocialIsland,Tables,UnknowPass,Wardrobe,XMission,loginInfoFile.json,MailPhoneLogin.json,BP_BuffGuid_Save.sav,BP_WeakGuidSave.sav,ChoosingZoneId.sav,iTOPPrefs.sav,playerprefs*,BillboardSlapData*,personalprefs*,RecruitFilterSetting*,CommonSaveGame*,SyncMatchAndChatLanguage*,MiscInfo.sav,NewPlayerprefsSwitcher.json,LoginBackUp,VideoPlayCount_0.json}
#Global
rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.tencent.ig/{app_*,cache,code_cache,no_backup,files,shared_prefs}
rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.tencent.ig/databases/{*-journal,crashSight_db_,__hs_log_store,awss3transfertable.db}
touch /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.tencent.ig/{files,app_crashrecord,app_crashSight,shared_prefs,app_webview}
touch /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.tencent.ig/databases/{crashSight_db_,__hs_log_store,awss3transfertable.db}
chmod 000 /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.tencent.ig/{files,app_crashrecord,app_crashSight,shared_prefs,app_webview}
chmod 000 /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.tencent.ig/databases/{crashSight_db_,__hs_log_store,awss3transfertable.db,*}
chmod 777 /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.tencent.ig/databases/iMSDK.db
#Data Directory
rm -rf /storage/emulated/0/.backups/com.pubg.imobile
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/{cache,prex_8bfb7f0a.dat}
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/cache
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/{TGPA,ca-bundle.pem,login-identifier.txt,vmpcloudconfig.json,.fff,tbslog,cacheFile.txt,hawk_data,ProgramBinaryCache}
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/{Engine,Epic*}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Demos,Logs,MMKV,RoleInfo,RoleIdnfo,TableDatas,UpdateInfo,PufferEifs0,PufferEifs1,PufferTmpDir,ImageDownload,Coverversion.ini,apollo_*,Screenshots,WeaponDIY,StatEventReportedFlag,Avatar,GameErrorNoRecords,MoviesPakDir,Avatar,Voices}
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Demos,Logs,MMKV,PufferEifs0,PufferEifs1}
#Root
rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.tencent.ig/{app_appcache,app_bugly,app_geolocation,app_textures,cache,code_cache,no_backup,app_cache,app_tmpcache}
rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.tencent.ig/databases/*-journal
#Phone
rm -rf /storage/emulated/0/{ASD,puex_dfaa3cad.dat}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/prex_8bfb7f0a.dat
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/{TGPA,ca-bundle.pem,login-identifier.txt,vmpcloudconfig.json,.fff,tbslog,cacheFile.txt,hawk_data}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/{Engine,Epic*}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Demos,Logs,MMKV,RoleInfo,RoleIdnfo,TableDatas,UpdateInfo,PufferEifs0,PufferEifs1,PufferTmpDir,ImageDownload,Coverversion.ini,apollo_*,Screenshots,WeaponDIY,StatEventReportedFlag,Avatar,GameErrorNoRecords,MoviesPakDir,Avatar,Voices}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_pufferpatch_*,puffer_temp,*_cures.ifs.cures,apollo_reslist.flistnewlist,*_cures.ifs,new.filelist,*_cures.ifs.res,apollo_reslist.flist,filelist.json,PufferFileListAddtional.json,PufferFileList.json}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/{Activity,Arena,Commercial,Chat,Friend,PersonSpace,Rp,Store,Task,Download,GEM,https*,Loading,Lobby,LobbyBubble,Login,Match,Notice,Pet,PufferDownload,RoleInfo,Season,Setting,SocialIsland,Tables,UnknowPass,Wardrobe,XMission,loginInfoFile.json,MailPhoneLogin.json,BP_BuffGuid_Save.sav,BP_WeakGuidSave.sav,ChoosingZoneId.sav,iTOPPrefs.sav,playerprefs*,BillboardSlapData*,personalprefs*,RecruitFilterSetting*,CommonSaveGame*,SyncMatchAndChatLanguage*,MiscInfo.sav,NewPlayerprefsSwitcher.json,LoginBackUp,VideoPlayCount_0.json}
rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.krmobile/{app_*,cache,code_cache,no_backup,files,shared_prefs}
rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.krmobile/databases/{*-journal,crashSight_db_,__hs_log_store,awss3transfertable.db}
touch /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.krmobile/{files,app_crashrecord,app_crashSight,shared_prefs,app_webview}
touch /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.krmobile/databases/{crashSight_db_,__hs_log_store,awss3transfertable.db}
chmod 000 /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.krmobile/{files,app_crashrecord,app_crashSight,shared_prefs,app_webview}
chmod 000 /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.krmobile/databases/{crashSight_db_,__hs_log_store,awss3transfertable.db,*}
chmod 777 /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.krmobile/databases/iMSDK.db
#Data Directory
rm -rf /storage/emulated/0/{ASD,puex_dfaa3cad.dat}
rm -rf /storage/emulated/0/.backups/com.pubg.imobile
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/{cache,prex_8bfb7f0a.dat}
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/cache
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/{TGPA,ca-bundle.pem,login-identifier.txt,vmpcloudconfig.json,.fff,tbslog,cacheFile.txt,hawk_data,ProgramBinaryCache}
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/ProgramBinaryCache
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/{Engine,Epic*}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Intermediate
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Demos,Logs,MMKV,RoleInfo,RoleIdnfo,TableDatas,UpdateInfo,PufferEifs0,PufferEifs1,PufferTmpDir,ImageDownload,Coverversion.ini,apollo_*,Screenshots,WeaponDIY,StatEventReportedFlag,Avatar,GameErrorNoRecords,MoviesPakDir,Avatar,Voices}
touch /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Demos,Logs,MMKV,PufferEifs0,PufferEifs1}
#Root
rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.krmobile/{app_appcache,app_bugly,app_geolocation,app_textures,cache,code_cache,no_backup,app_cache,app_tmpcache}
rm -rf /data/user/0/com.pubg.imobilex/blackbox/data/user/0/com.pubg.krmobile/databases/*-journal
#Phone
rm -rf /storage/emulated/0/{ASD,puex_dfaa3cad.dat}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/prex_8bfb7f0a.dat
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/{TGPA,ca-bundle.pem,login-identifier.txt,vmpcloudconfig.json,.fff,tbslog,cacheFile.txt,hawk_data}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/{Engine,Epic*}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/{Demos,Logs,MMKV,RoleInfo,RoleIdnfo,TableDatas,UpdateInfo,PufferEifs0,PufferEifs1,PufferTmpDir,ImageDownload,Coverversion.ini,apollo_*,Screenshots,WeaponDIY,StatEventReportedFlag,Avatar,GameErrorNoRecords,MoviesPakDir,Avatar,Voices}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/{res_pufferpatch_*,puffer_temp,*_cures.ifs.cures,apollo_reslist.flistnewlist,*_cures.ifs,new.filelist,*_cures.ifs.res,apollo_reslist.flist,filelist.json,PufferFileListAddtional.json,PufferFileList.json}
rm -rf /storage/emulated/0/Android/data/com.pubg.imobilex/files/blackbox/storage/emulated/0/Android/data/com.pubg.krmobile/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/SaveGames/{Activity,Arena,Commercial,Chat,Friend,PersonSpace,Rp,Store,Task,Download,GEM,https*,Loading,Lobby,LobbyBubble,Login,Match,Notice,Pet,PufferDownload,RoleInfo,Season,Setting,SocialIsland,Tables,UnknowPass,Wardrobe,XMission,loginInfoFile.json,MailPhoneLogin.json,BP_BuffGuid_Save.sav,BP_WeakGuidSave.sav,ChoosingZoneId.sav,iTOPPrefs.sav,playerprefs*,BillboardSlapData*,personalprefs*,RecruitFilterSetting*,CommonSaveGame*,SyncMatchAndChatLanguage*,MiscInfo.sav,NewPlayerprefsSwitcher.json,LoginBackUp,VideoPlayCount_0.json}